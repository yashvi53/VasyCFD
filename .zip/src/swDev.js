
// export default function swDev() {
//   let swUrl = `http://http://192.168.175.93:3002/sw.js`
//   navigator.serviceWorker.register(swUrl).then((response)=>{
//     console.warn("registered service worker",response)
//   })
// }

